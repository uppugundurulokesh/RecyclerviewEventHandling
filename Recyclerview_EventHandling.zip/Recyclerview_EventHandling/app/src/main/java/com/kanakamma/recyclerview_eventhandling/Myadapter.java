package com.kanakamma.recyclerview_eventhandling;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Kanakamma on 5/12/2018.
 */

public class Myadapter extends RecyclerView.Adapter<Myadapter.Myviewholder>  {
    ArrayList<Pojo> mylist;
    Context ctx;

    public Myadapter(MainActivity mainActivity, ArrayList<Pojo> list) {
        ctx=mainActivity;
        mylist=list;
    }

    @Override
    public Myadapter.Myviewholder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(ctx).inflate(R.layout.myrow,parent,false);


        return new Myviewholder(v,ctx,mylist);
    }

    @Override
    public void onBindViewHolder(Myadapter.Myviewholder holder, int position) {

         Pojo p=mylist.get(position);
         holder.tv.setText(p.getName());
         holder.img.setImageResource(p.getImage());


    }

    @Override
    public int getItemCount() {
        return mylist.size();
    }


    public class Myviewholder extends RecyclerView.ViewHolder implements View.OnClickListener {

       ImageView img;
       TextView tv;
       Context ct;
       ArrayList<Pojo> plist;

        public Myviewholder(View itemView,Context ct,ArrayList<Pojo> plist) {
            super(itemView);
            itemView.setOnClickListener(this);
            this.ct=ct;
            this.plist=plist;
            img=itemView.findViewById(R.id.imageView);
            tv=itemView.findViewById(R.id.textview);
        }

        @Override
        public void onClick(View v) {
            int pos=getAdapterPosition();
            Pojo pojo=this.plist.get(pos);
            Intent i=new Intent(ct,DetailsActivity.class);
           // i.putExtra()Extra("Image_Id",pojo.getImage());
            i.putExtra("Image_Id",pojo.getImage());
            i.putExtra("Image_Name",pojo.getName());
            ct.startActivity(i);
        }
    }
}

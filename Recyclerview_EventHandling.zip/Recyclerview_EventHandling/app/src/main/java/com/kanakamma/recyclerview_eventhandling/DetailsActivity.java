package com.kanakamma.recyclerview_eventhandling;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailsActivity extends AppCompatActivity {

   ImageView imageView;
   TextView tv;
   Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        tv=findViewById(R.id.textView2);
        imageView=findViewById(R.id.imageView2);
        toolbar=findViewById(R.id.tool);
        toolbar.setTitle(getIntent().getStringExtra("Image_Name"));

        tv.setText(getIntent().getStringExtra("Image_Name"));
        imageView.setImageResource(getIntent().getIntExtra("Image_Id",00));

    }
}

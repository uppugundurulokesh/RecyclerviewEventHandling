package com.kanakamma.recyclerview_eventhandling;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

   RecyclerView recyclerView;
   Pojo p;
   ArrayList<Pojo> list;
  String[] name={"one","two","three"};
    //String[] myname;
   int[] image={R.drawable.one,R.drawable.two,R.drawable.three};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.rec);
		Toast.makeText(this,"hai",Toast.LENGTH_LONG).show();
        list=new ArrayList<Pojo>();
       // myname=getResources().getStringArray(R.array.name);

        int i=0;
        for (String ding : name)
        {
            Pojo p=new Pojo(name[i],image[i]);
            list.add(p);
            i++;
        }

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
       Myadapter myadapter=new Myadapter(this,list);
        recyclerView.setAdapter(myadapter);

    }
}

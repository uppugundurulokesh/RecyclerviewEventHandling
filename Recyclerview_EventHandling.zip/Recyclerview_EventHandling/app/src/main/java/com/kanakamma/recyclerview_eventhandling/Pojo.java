package com.kanakamma.recyclerview_eventhandling;

/**
 * Created by Kanakamma on 5/12/2018.
 */

class Pojo {
String name;
int image;

    public Pojo(String s, int i) {
        this.name=s;
        this.image=i;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
